jQuery(document).ready(function($) {
    var browserWidth = $( window ).width();
    if (browserWidth>=375) {
        $(".logo").addClass('redLogoTransformed');
    $(".logoMask").addClass('logoWordsTransformed');
    };
    

    $(".contactDiv").click(function(event) {
        $(".contactHidden").show('4000', function() {
        });
    });
    $("#menuButton").click(function(event) {
        $(".menuOver").toggleClass("menuOpened");
    });
    $("#menuButtonInMenu").click(function(event) {
        $(".menuOver").toggleClass("menuOpened");
    });
    // $(".simpleCalculatorNumber").maskMoney({precision:"0", allowNegative: false, thousands:' ' });
    var simpleVkladValue, simpleRange, simpleCapit, simplePercent, selectedRangeText, simpleYouEarn, simpleRangeYear, totalProfit, monthProfit, monthRange;
    var daysInYear = 365;
    if ($(".pageBack").hasClass('curVkladBack')) {
        calculateCur();

    } else {
        calculate();

    };

    $('.changeHandlerInput').on('input', function(e) {
        if ($(".pageBack").hasClass('curVkladBack')) {
            calculateCur();

        } else {
            calculate();

        };
    });
    $(".changeHandler").change(function() {
        if ($(".pageBack").hasClass('curVkladBack')) {
            calculateCur();

        } else {
            calculate();

        };
    });

    function calculate(e) {

        simpleVkladValue = $(".simpleCalculatorNumber").val();
        simpleVkladValue = parseInt(simpleVkladValue);
        simpleRange = $("select[name='simpleCalcMonth']").val();
        simpleRange = parseInt(simpleRange);

        simpleCapit = $("select[name='capitalizationSelect']").val();
        selectedRangeText = $("select[name='simpleCalcMonth'] option:selected").text();


        if (simpleCapit === "w/oCapit") {
            // проценты с капитализацией
            switch (simpleRange) {
                case 180:
                    simpleRangeYear = 0.5;
                    if (simpleVkladValue >= 150000 && simpleVkladValue < 500000) {
                        simplePercent = 7.5;
                    } else if (simpleVkladValue >= 500000 && simpleVkladValue < 1500000) {
                        simplePercent = 9;
                    } else if (simpleVkladValue >= 1500000 && simpleVkladValue < 5000000) {
                        simplePercent = 11;
                    } else if (simpleVkladValue >= 5000000) {
                        simplePercent = 13;
                    };

                    break;
                case 365:
                    simpleRangeYear = 1;
                    if (simpleVkladValue >= 150000 && simpleVkladValue < 500000) {
                        simplePercent = 15;
                    } else if (simpleVkladValue >= 500000 && simpleVkladValue < 1500000) {
                        simplePercent = 17.5;
                    } else if (simpleVkladValue >= 1500000 && simpleVkladValue < 5000000) {
                        simplePercent = 20.5;
                    } else if (simpleVkladValue >= 5000000) {
                        simplePercent = 24;
                    };
                    break;
                case 730:
                    simpleRangeYear = 2;
                    if (simpleVkladValue >= 150000 && simpleVkladValue < 500000) {
                        simplePercent = 16.5;
                    } else if (simpleVkladValue >= 500000 && simpleVkladValue < 1500000) {
                        simplePercent = 19;
                    } else if (simpleVkladValue >= 1500000 && simpleVkladValue < 5000000) {
                        simplePercent = 22;
                    } else if (simpleVkladValue >= 5000000) {
                        simplePercent = 25;
                    };
                    break;
                case 1095:
                    simpleRangeYear = 3;
                    if (simpleVkladValue >= 150000 && simpleVkladValue < 500000) {
                        simplePercent = 18;
                    } else if (simpleVkladValue >= 500000 && simpleVkladValue < 1500000) {
                        simplePercent = 20;
                    } else if (simpleVkladValue >= 1500000 && simpleVkladValue < 5000000) {
                        simplePercent = 23.5;
                    } else if (simpleVkladValue >= 5000000) {
                        simplePercent = 26.5;
                    };
                    break;
            }
        } else {
            // проценты без капитализации
            switch (simpleRange) {
                case 180:
                    simpleRangeYear = 0.5;
                    if (simpleVkladValue >= 150000 && simpleVkladValue < 500000) {
                        simplePercent = 8;
                    } else if (simpleVkladValue >= 500000 && simpleVkladValue < 1500000) {
                        simplePercent = 9.5;
                    } else if (simpleVkladValue >= 1500000 && simpleVkladValue < 5000000) {
                        simplePercent = 11.5;
                    } else if (simpleVkladValue >= 5000000) {
                        simplePercent = 14;
                    };
                    break;
                case 365:
                    simpleRangeYear = 1;
                    if (simpleVkladValue >= 150000 && simpleVkladValue < 500000) {
                        simplePercent = 16.5;
                    } else if (simpleVkladValue >= 500000 && simpleVkladValue < 1500000) {
                        simplePercent = 19;
                    } else if (simpleVkladValue >= 1500000 && simpleVkladValue < 5000000) {
                        simplePercent = 22;
                    } else if (simpleVkladValue >= 5000000) {
                        simplePercent = 25;
                    };
                    break;
                case 730:
                    simpleRangeYear = 2;
                    if (simpleVkladValue >= 150000 && simpleVkladValue < 500000) {
                        simplePercent = 18;
                    } else if (simpleVkladValue >= 500000 && simpleVkladValue < 1500000) {
                        simplePercent = 19.75;
                    } else if (simpleVkladValue >= 1500000 && simpleVkladValue < 5000000) {
                        simplePercent = 23.5;
                    } else if (simpleVkladValue >= 5000000) {
                        simplePercent = 26.5;
                    };
                    break;
                case 1095:
                    simpleRangeYear = 3;
                    if (simpleVkladValue >= 150000 && simpleVkladValue < 500000) {
                        simplePercent = 18.75;
                    } else if (simpleVkladValue >= 500000 && simpleVkladValue < 1500000) {
                        simplePercent = 21.5;
                    } else if (simpleVkladValue >= 1500000 && simpleVkladValue < 5000000) {
                        simplePercent = 24.5;
                    } else if (simpleVkladValue >= 5000000) {
                        simplePercent = 28;
                    };
                    break;
            }
        };
        if (simpleVkladValue < 150000 || isNaN(simpleVkladValue)) {
            $(".calculatedText").css("color", "gray");
            $(".calcGraphCommonWrapper").css("filter", "blur(5px)");
        } else {
            $(".calculatedText").css("color", "white");
            $(".calcGraphCommonWrapper").css("filter", "blur(0)");
            $(".simpleCalcPercent").html(simplePercent);
            $(".getGraphCalc").html(simplePercent);
            $(".simpleCalcFinalMonth").html(selectedRangeText);
            $(".rangeGraphCalc").html(selectedRangeText);
            $(".investedGraphCalc").html(simpleVkladValue);
            $(".graphInvested").html(simpleVkladValue);

            if (simpleCapit === "w/oCapit") {
                simpleYouEarn = simpleVkladValue + simpleVkladValue * simplePercent * simpleRange / daysInYear / 100;
                simpleYouEarn = Math.round(simpleYouEarn);
            } else {


                var percentInPieces = simplePercent / 100;
                var baseForExponenting = 1 + percentInPieces / 12;
                var calcExponent = 12 * simpleRangeYear;
                var exponentedValue = Math.pow(baseForExponenting, calcExponent);

                simpleYouEarn = simpleVkladValue * exponentedValue;
                simpleYouEarn = Math.round(simpleYouEarn);

                //дописать сколько месяцев в периуде

            };
            $(".simpleCalcFinalPrice").html(simpleYouEarn);
            $(".graphTotalEarn").html(simpleYouEarn);
            totalProfit = simpleYouEarn - simpleVkladValue;
            monthRange = 12 * simpleRangeYear;

            monthProfit = totalProfit / monthRange;
            monthProfit = Math.round(monthProfit);
            $(".yourProfitGraphCalc").html(totalProfit);
            $(".profitPerMonthGraphCalc").html(monthProfit);
        };




    };

    function calculateCur(e) {

        simpleVkladValue = $(".simpleCalculatorNumber").val();
        simpleVkladValue = parseInt(simpleVkladValue);
        simpleRange = $("select[name='simpleCalcMonth']").val();
        simpleRange = parseInt(simpleRange);


        selectedRangeText = $("select[name='simpleCalcMonth'] option:selected").text();




        // проценты без капитализации
        switch (simpleRange) {
            case 180:
                simpleRangeYear = 0.5;
                if (simpleVkladValue >= 4000 && simpleVkladValue < 25000) {
                    simplePercent = 7.5;
                } else if (simpleVkladValue >= 25000 && simpleVkladValue < 75000) {
                    simplePercent = 8.5;
                } else if (simpleVkladValue >= 75000 && simpleVkladValue < 250000) {
                    simplePercent = 9.75;
                } else if (simpleVkladValue >= 250000) {
                    simplePercent = 11;
                };
                break;
            case 365:
                simpleRangeYear = 1;
                if (simpleVkladValue >= 4000 && simpleVkladValue < 25000) {
                    simplePercent = 9.5;
                } else if (simpleVkladValue >= 25000 && simpleVkladValue < 75000) {
                    simplePercent = 10.5;
                } else if (simpleVkladValue >= 75000 && simpleVkladValue < 250000) {
                    simplePercent = 12;
                } else if (simpleVkladValue >= 250000) {
                    simplePercent = 13.5;
                };
                break;
            case 730:
                simpleRangeYear = 2;
                if (simpleVkladValue >= 4000 && simpleVkladValue < 25000) {
                    simplePercent = 10.5;
                } else if (simpleVkladValue >= 25000 && simpleVkladValue < 75000) {
                    simplePercent = 11.5;
                } else if (simpleVkladValue >= 75000 && simpleVkladValue < 250000) {
                    simplePercent = 13;
                } else if (simpleVkladValue >= 250000) {
                    simplePercent = 15;
                };
                break;
            case 1095:
                simpleRangeYear = 3;
                if (simpleVkladValue >= 4000 && simpleVkladValue < 25000) {
                    simplePercent = 12;
                } else if (simpleVkladValue >= 25000 && simpleVkladValue < 75000) {
                    simplePercent = 12.5;
                } else if (simpleVkladValue >= 75000 && simpleVkladValue < 250000) {
                    simplePercent = 14.5;
                } else if (simpleVkladValue >= 250000) {
                    simplePercent = 17;
                };
                break;
        }

        if (simpleVkladValue < 4000 || isNaN(simpleVkladValue)) {
            $(".calculatedText").css("color", "gray");
            $(".calcGraphCommonWrapper").css("filter", "blur(5px)");
        } else {
            $(".calculatedText").css("color", "white");
            $(".calcGraphCommonWrapper").css("filter", "blur(0)");
            $(".simpleCalcPercent").html(simplePercent);
            $(".getGraphCalc").html(simplePercent);
            $(".simpleCalcFinalMonth").html(selectedRangeText);
            $(".rangeGraphCalc").html(selectedRangeText);
            $(".investedGraphCalc").html(simpleVkladValue);
            $(".graphInvested").html(simpleVkladValue);


            simpleYouEarn = simpleVkladValue + simpleVkladValue * simplePercent * simpleRange / daysInYear / 100;
            simpleYouEarn = Math.round(simpleYouEarn);

            $(".simpleCalcFinalPrice").html(simpleYouEarn);
            $(".graphTotalEarn").html(simpleYouEarn);
            totalProfit = simpleYouEarn - simpleVkladValue;
            monthRange = 12 * simpleRangeYear;

            monthProfit = totalProfit / monthRange;
            monthProfit = Math.round(monthProfit);
            $(".yourProfitGraphCalc").html(totalProfit);
            $(".profitPerMonthGraphCalc").html(monthProfit);
        };




    };



});