<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package kpk
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<meta charset="UTF-8">
    
    <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/styles.css?ver=1.3">
    <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/fonts.css?ver=1.2">
    <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/media.css?ver=1.2">
    <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/bootstrapHD.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,600|Russo+One&amp;subset=cyrillic" rel="stylesheet">
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/jquery-3.2.1.min.js"></script>
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/jquery.maskMoney.min.js"></script>
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/main.js?ver=1.4"></script>
    <script src="https://use.fontawesome.com/8524106ee3.js"></script>
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo get_stylesheet_directory_uri(); ?>/img/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo get_stylesheet_directory_uri(); ?>/img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo get_stylesheet_directory_uri(); ?>/img/favicon-16x16.png">
<link rel="manifest" href="<?php echo get_stylesheet_directory_uri(); ?>/img/manifest.json">
<link rel="mask-icon" href="<?php echo get_stylesheet_directory_uri(); ?>/img/safari-pinned-tab.svg" color="#5bbad5">
<link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri(); ?>/img/favicon.ico">
<meta name="msapplication-config" content="<?php echo get_stylesheet_directory_uri(); ?>/img/browserconfig.xml">
<meta name="theme-color" content="#ffffff">
<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter46976454 = new Ya.Metrika({
                    id:46976454,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true,
                    webvisor:true,
                    trackHash:true
                });
            } catch(e) { }
        });
 
        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";
 
        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/46976454" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    
    <div class="pageWrapper">
        <div class="firstBackScreen">
            <i class="fa fa-bars fa-3x" aria-hidden="true" id="menuButton"></i>
            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logoRed.svg?ver=1.1" alt="Логотип КПК" class="logo">
            <div class="logoMask"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logoWord.svg" alt="Логотип КПК" class="wordLogo"></div>
            
            <div class="menuOver">
                <div class="fixedToRel">
                   <i class="fa fa-bars fa-3x" aria-hidden="true" id="menuButtonInMenu"></i> 
                    <ul>
                        <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">На главную</a></li>
                        <li><a href="about">Информация об организации</a></li>
                        <li><a href="saved">Защита ваших вкладов</a></li>
                        <li><a href="contacts">Контакты</a></li>
                    </ul>
                    <ul class="centerLinksOver">
                        <li><a href="kpkvklad">Вклад в КПК</a></li>
                        <li><a href="vkladwithcap">Вклад с капитализацией</a></li>
                        <li><a href="inovklad">Валютный вклад</a></li>
                        <!-- <li><a href="vkladcals">Калькулятор вклада</a></li> -->
                    </ul>
                    <ul class="bottomContacts">
                        <li><a href="tel:88002344444">8(800) 234-44-44</a></li>
                        <li><span class="freeCall">Звонок бесплатный</span></li>
                    </ul>
                </div>
            </div>