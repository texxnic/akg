function availableOn (osType,lang,) {
	
}