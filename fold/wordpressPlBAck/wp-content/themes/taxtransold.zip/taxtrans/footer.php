<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package taxtrans
 */

?>
    </div>
    <!-- #content -->
    </div>
    <!-- #page -->
    <?php wp_footer(); ?>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/owl.carousel.min.js"></script>
  <script src="//api-maps.yandex.ru/2.1/?lang=ru_RU&amp;load=SuggestView&amp;onload=onLoad"></script>
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/TweenMax.js"></script>
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/TimelineMax.js"></script>
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/TimelineMax.js"></script>

<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/ScrollMagic.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/jquery.validate.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/animation.gsap.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/animation.velocity.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/plugins/debug.addIndicators.min.js"></script>

    

<script>
var blurElement = {a:0};
var vwBlurElement = {a:5};
var i40BlurElement = {a:5};
var startVal = {a:0};
var vwStartVal = {a:0};
 var controller = new ScrollMagic.Controller();

    // build scene
   var header = new ScrollMagic.Scene({triggerElement: "#main", offset:15})
   .triggerHook(0.01)
                    .setClassToggle("header", "smaller") // add class toggle
                   
                    .addTo(controller);
    var scene = new ScrollMagic.Scene({triggerElement: ".autopark", duration: 250})
                    // animate color and top border in relation to scroll position
                    .setTween(blurElement, {a:5, onUpdate:applyBlur}) // the tween durtion can be omitted and defaults to 1
                    // add indicators (requires plugin)
                    .addTo(controller);

    var scene2 = new ScrollMagic.Scene({triggerElement: ".autopark", duration: 250})
     .setTween(vwBlurElement, {a:0, onUpdate:vwApplyBlur}) // the tween durtion can be omitted and defaults to 1
                   // add indicators (requires plugin)
                    .addTo(controller);
    var scene3 = new ScrollMagic.Scene({triggerElement: ".autopark", offset:250, duration: 250})
     .setTween(vwBlurElement, {a:5, onUpdate:vwApplyBlur}) // the tween durtion can be omitted and defaults to 1
                     // add indicators (requires plugin)
                    .addTo(controller);
     var scene4 = new ScrollMagic.Scene({triggerElement: ".autopark", offset:250, duration: 250})
     .setTween(i40BlurElement, {a:0, onUpdate:i40ApplyBlur}) // the tween durtion can be omitted and defaults to 1
                     // add indicators (requires plugin)
                    .addTo(controller);
var scene5 = new ScrollMagic.Scene({triggerElement: ".autopark", offset:150, duration: 100})
                    // animate color and top border in relation to scroll position
                    .setTween('.skodaName',{opacity:0}) // the tween durtion can be omitted and defaults to 1
                    // add indicators (requires plugin)
                    .addTo(controller);

var vwNameRenuva = new ScrollMagic.Scene({triggerElement: ".autopark", offset:150, duration: 100})
                    // animate color and top border in relation to scroll position
                    .setTween('.vwName',{opacity:1}) // the tween durtion can be omitted and defaults to 1
                     // add indicators (requires plugin)
                    .addTo(controller);
var vwNameRenuva2 = new ScrollMagic.Scene({triggerElement: ".autopark", offset:250, duration: 100})
                    // animate color and top border in relation to scroll position
                    .setTween('.vwName',{opacity:0}) // the tween durtion can be omitted and defaults to 1
                     // add indicators (requires plugin)
                    .addTo(controller);
var i40NameRenuva = new ScrollMagic.Scene({triggerElement: ".autopark", offset:250, duration: 100})
                    // animate color and top border in relation to scroll position
                    .setTween('.i40Name',{opacity:1}) // the tween durtion can be omitted and defaults to 1
                     // add indicators (requires plugin)
                    .addTo(controller);
var skodaAnim = new ScrollMagic.Scene({triggerElement: ".autopark", duration: 800})
                    // animate color and top border in relation to scroll position
                  .setTween(startVal, {a:-500, onUpdate:skodaSlide})
                     // add indicators (requires plugin)
                    .addTo(controller);                    
var vwAnim = new ScrollMagic.Scene({triggerElement: ".autopark", duration: 800})
                    // animate color and top border in relation to scroll position
                  .setTween(vwStartVal, {a:-200, onUpdate:vwSlide})
                     // add indicators (requires plugin)
                    .addTo(controller);  
var autoparkParralax = new ScrollMagic.Scene({triggerElement: ".order", offset: -400, duration: 1600})
                    // animate color and top border in relation to scroll position
                  .setTween('.autoparkParralax',{left:200})
                     // add indicators (requires plugin)
                    .addTo(controller);  
var aboutUsParralax = new ScrollMagic.Scene({triggerElement: ".order", duration: 1600})
                    // animate color and top border in relation to scroll position
                  .setTween('.aboutUsParralax',{right:-400})
                     // add indicators (requires plugin)
                    .addTo(controller);  


function skodaSlide(){
    TweenMax.set(['.skodaPhoto'], {transform:"translateX(" + startVal.a +"px)", }); 
    TweenMax.set(['.skodaName'], {transform:"translateX(" + startVal.a*0.8 +"px)", }); 
};
function vwSlide(){
    TweenMax.set(['.vwPhoto'], {transform:"translateX(" + vwStartVal.a +"px)", }); 
    TweenMax.set(['.vwName'], {transform:"translateX(" + vwStartVal.a*0.8 +"px)", }); 
};


function applyBlur()
  {
    TweenMax.set(['.skodaPhoto'], {webkitFilter:"blur(" + blurElement.a + "px)",filter:"blur(" + blurElement.a + "px)", }); 
    TweenMax.set(['.skodaName'], {webkitFilter:"blur(" + blurElement.a + "px)",filter:"blur(" + blurElement.a + "px)", });  
  };
  function vwApplyBlur()
  {
    TweenMax.set(['.vwPhoto'], {webkitFilter:"blur(" + vwBlurElement.a + "px)",filter:"blur(" + vwBlurElement.a + "px)"});  
     TweenMax.set(['.vwName'], {webkitFilter:"blur(" + vwBlurElement.a + "px)",filter:"blur(" + vwBlurElement.a + "px)"});  
  };
 function i40ApplyBlur()
  {
    TweenMax.set(['.i40Photo'], {webkitFilter:"blur(" + i40BlurElement.a + "px)",filter:"blur(" + i40BlurElement.a + "px)"}); 
    TweenMax.set(['.i40Name'], {webkitFilter:"blur(" + i40BlurElement.a + "px)",filter:"blur(" + i40BlurElement.a + "px)"});  
  };

</script>

    <script>



    

    $(document).ready(function() {




    var wvh = $(window).height();

        //GalleryButtons

        var galerry = $('.envira-gallery-wrap');

        function hideAll() {
            galerry.hide();
        }
        $("label[for='allCarsSwitch']").click(function() {
            galerry.show();
        });
        $("label[for='SkodaSwitch']").click(function() {
            hideAll();
            $('#envira-gallery-wrap-56').show();
        });
        $("label[for='VolkswagenSwitch']").click(function() {
            hideAll();
            $('#envira-gallery-wrap-57').show();
        });
        $("label[for='HyundaiSwitch']").click(function() {
            hideAll();
            $('#envira-gallery-wrap-22').show();
        });
        $("label[for='VIPtaxi']").click(function() {
            hideAll();
            
            $('#envira-gallery-wrap-155').show();
        });

        //GalleryButtonsEnd
        var owl = $(".owl-carousel");
        var owlData = $(".owl-carousel").data('owlCarousel');
        owl.owlCarousel({
            items: 1,

            autoplay: true,
            loop: true,
            autoplayTimeout: 10000

        });
 owl.on('changed.owl.carousel', function(event) {
$('svg').css({ fill: "#ffd100" });
                 switch (event.item.index){
             case 3:
        $('#checkList').css({ fill: "white" });

        break;
    case 4:
        $('#driverIco').css({ fill: "white" });
        break;
        case 5:
        $('#carWash').css({ fill: "white" });
        break;
        case 6:
        $('#roubleIco').css({ fill: "white" });
        break;
        case 7:
        $('#timeIco').css({ fill: "white" });
        break;


        };

            });
        $('#checkList').click(function(event) {
            owl.trigger('to.owl.carousel', 0);

        });
        $('#driverIco').click(function(event) {
            owl.trigger('to.owl.carousel', 1);

        });
        $('#carWash').click(function(event) {
            owl.trigger('to.owl.carousel', 2);

        });
        $('#roubleIco').click(function(event) {
            owl.trigger('to.owl.carousel', 3);

        });
        $('#timeIco').click(function(event) {
            owl.trigger('to.owl.carousel', 4);

        });

     
        $('.jumbo').css('height', wvh);

    
        $('#switch_right').click(function() {
            $('#dateTimeRow').removeClass('blur');
            $('.timeIco').removeClass('grayscale');
            $('#datetime').prop('disabled', false);



        });
        $('#switch_left').click(function() {
            $('#dateTimeRow').addClass('blur');
            $('.timeIco').addClass('grayscale');
            $('#datetime').prop('disabled', true);


        });

        $(window).keydown(function(event) {
            if (event.keyCode == 13) {
                event.preventDefault();
                return false;
            }
        });



        $(".mat-input").focus(function() {
            $(this).parent().addClass("is-active is-completed");
        });

        $(".mat-input").focusout(function() {
            if ($(this).val() === "")
                $(this).parent().removeClass("is-completed");
            $(this).parent().removeClass("is-active");
        })


        $('#nav-icon1').click(function() {
            if ($(this).hasClass('open')) {
                $('#mySidenav').css('width', 0);

                $('.phones').show();
                $('.phones').css('opacity', 1).delay(50000);
                $('#taxTransLogo').show();
                $('.headerRightContent').css('margin-right', 0);

            } else {
                if ($(window).width() > 410) {
                    $('#mySidenav').css('width', 250);
                    $('.phones').hide().delay(600);
                    $('.phones').css('opacity', 0);
                    $('.headerPhone').css('opacity', 0);
                    $('.headerRightContent').css('margin-right', 250);
                } else {
                    $('#mySidenav').css('width', 170);
                    $('.phones').hide().delay(600);
                    $('.phones').css('opacity', 0);
                    $('.headerPhone').css('opacity', 0);
                    $('.headerRightContent').css('margin-right', 170);
                };


            };
            $(this).toggleClass('open');
        });


    });
    </script>



    </html>
    </body>

    </html>