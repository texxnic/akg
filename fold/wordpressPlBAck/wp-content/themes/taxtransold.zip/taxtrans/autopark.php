<?php
/**
* Template Name: autopark
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package taxtrans
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

    <!-- Use any element to open the sidenav -->

    <div id="main">

       <div class="pageJumbo">
           <h2 class="whiteTxt animated zoomIn"><?php the_title(); ?></h2>
       </div>
       <div class="container contetPaddings txtAlignCenter">
    <div class="switch-field">
      
      <input type="radio" id="allCarsSwitch" name="switch_3"  checked/>
      <label for="allCarsSwitch">Все</label>
      <input type="radio" id="SkodaSwitch" name="switch_3"  />
      <label for="SkodaSwitch">Skoda</label>
      <input type="radio" id="VolkswagenSwitch" name="switch_3"  />
      <label for="VolkswagenSwitch">Volkswagen</label>
		<input type="radio" id="HyundaiSwitch" name="switch_3"  />
      <label for="HyundaiSwitch">Hyundai</label>
<input type="radio" id="VIPtaxi" name="switch_3"  />
      <label for="VIPtaxi">VIP такси</label>
    </div>
       <?php
			while ( have_posts() ) : the_post();

				get_template_part( 'template-parts/content', 'page' );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile; // End of the loop.
			?>
     

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_sidebar();


get_footer();


