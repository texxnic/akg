<?php
/**
* Template Name: standartPriceList
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package taxtrans
 */

get_header(); ?>
    <script src="//api-maps.yandex.ru/2.1/?lang=ru" type="text/javascript"></script>
    <div id="primary" class="content-area">
        <!-- Use any element to open the sidenav -->
        <div id="main" class="priceListMain">
            <div class="pageJumbo priceListJumbo">
                <h2 class="whiteTxt animated zoomIn"><?php the_title(); ?></h2>
            </div>
            <div class="container pageContent contetPaddings">
                <div id="allDirectionChanger">
                    <input type="radio" id="standartTaxiPrice" name="taxiType" value="standart" checked>
                    <label for="standartTaxiPrice">СТАНДАРТ</label>
                    <input type="radio" id="minivanTaxiPrice" name="taxiType" value="minivan">
                    <label for="minivanTaxiPrice">МИНИВЭН</label>
                    <input type="radio" id="sclassTaxiPrice" name="taxiType" value="sclass">
                    <label for="sclassTaxiPrice">S-class</label>
                    <input type="radio" id="vclassTaxiPrice" name="taxiType" value="vclass">
                    <label for="vclassTaxiPrice">V-class</label>
                    <input type="radio" id="gelenvagenTaxiPrice" name="taxiType" value="gelenvagen">
                    <label for="gelenvagenTaxiPrice">ГЕЛЕНДВАГЕН</label>
                </div>
              
                <div id="standartPriceList">
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3">
                            <img class="fullWidthImg" src="<?php echo get_stylesheet_directory_uri(); ?>/img/price/camry.jpg" alt="">
                        </div>
                    </div>
                    <div class="row odincovoPricesRow">
                        <div class="col-md-6">
                            <div class="priceOdincovo priceOdincovo1">
                                <h3>Одинцово и пригород</h3>
                                <input type="text" id="odincovoTableSeach" onkeyup="myFunction('odincovoTableSeach','odincovoOblastTable')" placeholder="Введите улицу">
                                <table id="odincovoOblastTable">
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Баковская улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Верхнее-Отрадное</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Верхне-Пролетарская улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Вокзальная улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>1-я Вокзальная улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Внуковская улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Восточная улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Глазынинская улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Железнодорожная улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Зеленая улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Западная улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Говорова улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Интернациональная улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Интернациональный проезд</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Коммунальный проезд</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Коммунистическая улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Комсомольская улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Красногорское шоссе</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Красногорский проезд</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Бульвар Любы Новоселовой</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Маковского улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Маршала Бирюзова улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Маршала Крылова улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Маршала Толубко улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Маршала Жукова улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Можайское шоссе</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Молодежная улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Неделина улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Нижнепролетарская улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Поселок БЗРИ</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Пионерская улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Новое Яскино улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Ново-Спортивная улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Привокзальная площадь</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Садовая улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Свободы улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Северная улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Советская улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Союзная улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Сосновая улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Солнечная улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Старое Яскино улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Транспортная улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Транспортный проезд</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Чикина улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Школьный проезд</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Школьная улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Южная улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Яскино улица</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>2-й Завод</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Трасса им.Л.Лазутиной</td>
                                        <td class="tdStyling" style=min-width:50px>600
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px></td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Старая Трехгорка:</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Вишневая</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Колхозная</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Можайское ш</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Полевая</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Чистяковой до 38д</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>платформа Трехгорка</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>д.Мамоново( со стороны можайского ш)</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Буденовское ш</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Баковка -4</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>ул.Вокзальная</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Вокзальный тупик</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Колхозная </td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Лесная</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Овражный тупик</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Луч</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Лохино:</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>1-я Советская</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>2-я Советская</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Садовая</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>ЖК Сколковский ( ул. Сколковская)</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Акулово: </td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Довиль</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Акуловская</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Железнодорожная</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Полевая</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Д/О Озера</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Новая</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Школьная</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Гуссарская Баллада:</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Бородинская</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Дениса Давыдова</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Гвардейская</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Михаила Кутузова</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Триумфальная</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>пос Вниссок:</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Рябиновая</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Дружбы</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Березовая </td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Кленовая</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Селекционная</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Липовая</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>с Дубки</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>ст. Пионерская ( до переезда)</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>д.Губкино</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>д.Глазынино</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>9-й микр.:</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>ул.Белорусская</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Одинцово 1</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>ул.Ракетчиков</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>АКОС</td>
                                        <td class="tdStyling" style=min-width:50px>750
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Баковка ( Минское ш):</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>1 Мая</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Буденовское ш</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Лесная</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Полевая</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Нагорная</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>пер.Рыбалко</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Сетуньский тупик</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Луначарского</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Трудовая</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Хутор Одинцовский</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>ДПК Луч ( на минском ш)</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Мамоново ( на минском ш)</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>ст. Пионерская ( после переезда)</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Никонорово</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Лохино-ВИЛС</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Новая Трехгорка:</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Кутузовская</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Чистяковой (с д 40)</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>Озерная 115 ( конфитюр)</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tdStyling" style=min-width:50px>рублевский проезд</td>
                                        <td class="tdStyling" style=min-width:50px>900
                                            <br>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="priceOdincovo priceOdincovo2">
                                <h3>Область и другое</h3>
                                <div id="allDirectionChanger">
                                    <input type="radio" id="fromAll" name="driveType" value="from" checked>
                                    <label for="fromAll">Из Одинцово</label>
                                    <input type="radio" id="toAll" name="driveType" value="to">
                                    <label for="toAll">В Одинцово</label>
                                    <input type="radio" name="driveType" id="fromToAll" value="fromTo">
                                    <label for="fromToAll">Туда-обратно</label>
                                </div>
                                <input type="text" id="allTableSearch" onkeyup="myFunction('allTableSearch','odincovoAllTable')" placeholder="Введите город, станцию метро, рынок">
                              
                                <div id="calcButton" class="animated fadeInUp hidden">К сожалению вашего места нет в списке. Воспользуйтесь калькулятором.</div>
                            </div>
                        </div>
                       
                    </div>
                    
                    <!-- The Modal -->
                    <div id="myModal" class="modal">
                        <!-- Modal content -->
                        <div class="modal-content  animated fadeInUp">
                            <span class="close">&times;</span>
                            <p>Калькулятор поездки</p>
                            <div class="row">
                                <div class="col-sm-8">
                                    <div id="map"></div>
                                </div>
                                <div class="col-sm-4">
                                    <p>Поездка: <span class="adressFrom"></span> <span class="adressTo"></span>
                                        <br>Протяженностью:<span class="len"></span>
                                        <br> И ценой:<span class="price"></span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               
                
                <div class="oplataButton">
                        <p class="whiteTxt">Оплатить <span class="place"></span> <span class="tripPrice">20000</span>₽</p>
                    </div>

                <style>
                .modal {
                    display: none;
                    /* Hidden by default */
                    position: fixed;
                    /* Stay in place */
                    z-index: 1;
                    /* Sit on top */
                    left: 0;
                    top: 0;
                    width: 100%;
                    /* Full width */
                    height: 100%;
                    /* Full height */
                    overflow: auto;
                    /* Enable scroll if needed */
                    background-color: rgb(0, 0, 0);
                    /* Fallback color */
                    background-color: rgba(0, 0, 0, 0.4);
                    /* Black w/ opacity */
                    border-radius: 15px;
                    transition: 0s;
                }
                /* Modal Content/Box */

                .modal-content {
                    background-color: #fefefe;
                    margin: 15% auto;
                    /* 15% from the top and centered */
                    padding: 20px;
                    border: 1px solid #888;
                    width: 80%;
                    /* Could be more or less, depending on screen size */
                }
                /* The Close Button */

                .close {
                    color: #aaa;
                    float: right;
                    font-size: 28px;
                    font-weight: bold;
                }

                .close:hover,
                .close:focus {
                    color: black;
                    text-decoration: none;
                    cursor: pointer;
                }

                #calcButton {
                    background-color: red;
                }

                #map {
                    width: 100%;
                    height: 400px;
                    padding: 0;
                    margin: 0;
                }
                </style>
                <script>

                $('document').ready(function() {


                    // Get the modal
                    var modal = document.getElementById('myModal');

                    // Get the button that opens the modal
                    var btn = document.getElementById("calcButton");

                    // Get the <span> element that closes the modal
                    var span = document.getElementsByClassName("close")[0];

                    // When the user clicks on the button, open the modal 
                    btn.onclick = function() {
                        modal.style.display = "block";
                    }

                    // When the user clicks on <span> (x), close the modal
                    span.onclick = function() {
                        modal.style.display = "none";
                    }

                    // When the user clicks anywhere outside of the modal, close it
                    window.onclick = function(event) {
                        if (event.target == modal) {
                            modal.style.display = "none";
                        }
                    }


                });

                function init() {
                    var myMap = new ymaps.Map('map', {
                            center: [55.4521, 37.3704],
                            zoom: 10,
                            type: 'yandex#map',
                            behaviors: ['scrollZoom', 'drag'],
                            controls: []
                        }),
                        searchStartPoint = new ymaps.control.SearchControl({
                            options: {
                                useMapBounds: true,
                                noPlacemark: true,
                                noPopup: true,
                                placeholderContent: 'Откуда',
                                size: 'large'
                            }
                        }),
                        searchFinishPoint = new ymaps.control.SearchControl({
                            options: {
                                useMapBounds: true,
                                noCentering: true,
                                noPopup: true,
                                noPlacemark: true,
                                placeholderContent: 'Куда',
                                size: 'large',
                                float: 'none',
                                position: { left: 10, top: 44 }
                            }
                        }),
                        calculator = new DeliveryCalculator(myMap, myMap.getCenter());

                    myMap.controls.add(searchStartPoint);
                    myMap.controls.add(searchFinishPoint);

                    searchStartPoint.events.add('resultselect', function(e) {
                            var results = searchStartPoint.getResultsArray(),
                                selected = e.get('index'),
                                point = results[selected].geometry.getCoordinates();

                            calculator.setStartPoint(point);
                        })
                        .add('load', function(event) {
                            // По полю skip определяем, что это не дозагрузка данных.
                            // По getRusultsCount определяем, что есть хотя бы 1 результат.
                            if (!event.get('skip') && searchStartPoint.getResultsCount()) {
                                searchStartPoint.showResult(0);
                            }
                        });

                    searchFinishPoint.events.add('resultselect', function(e) {
                            var results = searchFinishPoint.getResultsArray(),
                                selected = e.get('index'),
                                point = results[selected].geometry.getCoordinates();

                            calculator.setFinishPoint(point);
                        })
                        .add('load', function(event) {
                            // По полю skip определяем, что это не дозагрузка данных.
                            // По getRusultsCount определяем, что есть хотя бы 1 результат.
                            if (!event.get('skip') && searchFinishPoint.getResultsCount()) {
                                searchFinishPoint.showResult(0);
                            }
                        });
                }

                function DeliveryCalculator(map, finish) {
                    this._map = map;
                    this._start = null;
                    this._route = null;

                    map.events.add('click', this._onClick, this);
                }

                var ptp = DeliveryCalculator.prototype;

                ptp._onClick = function(e) {
                    if (this._start) {
                        this.setFinishPoint(e.get('coords'));
                    } else {
                        this.setStartPoint(e.get('coords'));
                    }
                };

                ptp._onDragEnd = function(e) {
                    this.getDirection();
                }

                ptp.getDirection = function() {
                    if (this._route) {
                        this._map.geoObjects.remove(this._route);
                    }

                    if (this._start && this._finish) {
                        var self = this,
                            start = this._start.geometry.getCoordinates(),
                            finish = this._finish.geometry.getCoordinates();

                        ymaps.geocode(start, { results: 1 })
                            .then(function(geocode) {
                                var address = geocode.geoObjects.get(0) &&
                                    geocode.geoObjects.get(0).properties.get('balloonContentBody') || '';

                                ymaps.route([start, finish])
                                    .then(function(router) {
                                        var distance = Math.round(router.getLength() / 1000),
                                            message = '<span>Distance: ' + distance + 'км.</span><br/>' +
                                            '<span style="font-weight: bold; font-style: italic">cost of delivery: %sр.</span>';

                                        self._route = router.getPaths();

                                        self._route.options.set({ strokeWidth: 5, strokeColor: '0000ffff', opacity: 0.5 });
                                        self._map.geoObjects.add(self._route);
                                        self._start.properties.set('balloonContentBody', address + message.replace('%s', self.calculate(distance)));

                                    });
                            });
                        self._map.setBounds(self._map.geoObjects.getBounds())
                    }
                };

                ptp.setStartPoint = function(position) {
                    if (this._start) {
                        this._start.geometry.setCoordinates(position);
                    } else {
                        this._start = new ymaps.Placemark(position, { iconContent: 'А' }, { draggable: true });
                        this._start.events.add('dragend', this._onDragEnd, this);
                        this._map.geoObjects.add(this._start);
                    }
                    if (this._finish) {
                        this.getDirection();
                    }
                };

                ptp.setFinishPoint = function(position) {
                    if (this._finish) {
                        this._finish.geometry.setCoordinates(position);
                    } else {
                        this._finish = new ymaps.Placemark(position, { iconContent: 'Б' }, { draggable: true });
                        this._finish.events.add('dragend', this._onDragEnd, this);
                        this._map.geoObjects.add(this._finish);
                    }
                    if (this._start) {
                        this.getDirection();
                    }
                };

                ptp.calculate = function(len) {
                    // Константы.
                    var DELIVERY_TARIF = 30,
                        MINIMUM_COST = 500;

                    alert(start);
                    $('.len').html(len);
                    $('.price').html(len * DELIVERY_TARIF)
                    return Math.max(len * DELIVERY_TARIF, MINIMUM_COST);
                };

                ymaps.ready(init);



                function myFunction(searchName, tableName) {
                    // Declare variables 
                    var input, filter, table, tr, td, i;
                    var visible = $('#odincovoAllTable td:visible').length;
                    input = document.getElementById(searchName);
                    filter = input.value.toUpperCase();
                    table = document.getElementById(tableName);
                    tr = table.getElementsByTagName("tr");


                    // Loop through all table rows, and hide those who don't match the search query
                    for (i = 0; i < tr.length; i++) {
                        td = tr[i].getElementsByTagName("td")[0];
                        if (td) {
                            if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                                tr[i].style.display = "";
                            } else {
                                tr[i].style.display = "none";
                            }
                        }
                    }
                    var visible = $('#odincovoAllTable td:visible').length;
                    if (visible === 0) {
                        $('#calcButton').show();
                    } else {
                        $('#calcButton').hide();
                    };
                }
                </script>
            </div>
            <!-- #primary -->
            <?php
get_sidebar();


get_footer();